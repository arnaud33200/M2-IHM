#!/usr/bin/perl -w
#
# $Source: /projet/ivy/cvsroot/lib/ivy-perl/example/ivyprobe.pl,v $
# $Revision: 1.6 $
#
# $Author: mertz $
# $Date: 2002/06/10 09:38:25 $
#	This program is free software; you can redistribute it and/or
#	modify it under the terms of the GNU GPL General Public License
#	as published by the Free Software Foundation; either version 2
#	of the License, or (at your option) any later version.
#	      
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#	
#	You should have received a copy of the GNU General Public License
#	along with this program; if not, write to the Free Software
#	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA,
#	or refer to http://www.gnu.org/copyleft/gpl.html
#

use strict;
use Ivy;
use Getopt::Long;
use Term::ReadLine;
use Tk;
use Carp;

my $term = Term::ReadLine->new("ivyprobe.pl");
$term->tkRunning;

my $OUT = $term->OUT || $STDOUT;
#my $OUT = $STDOUT;

my $appliname = "IVYPROBE.PL";
my $bus;

# for each application gives the number of running instances
my %connected_applications;

# for each couple appli:host gives the number of application running on host
my %where_applications;

&check_options;

Ivy->init (-ivyBus => (defined $bus) ? $bus : undef,
	   -appName => $appliname,
#	   -loopMode => 'TK',
	   -loopMode => 'LOCAL',
	   -messWhenReady => "$appliname READY",
	   );

my $Ivyobj = Ivy->new(-statusFunc => \&statusFunc,
		      );

foreach my $regexp (@ARGV) {
    print $OUT "binding to $regexp\n";
    if ($regexp =~ /'(.*)'/) { $regexp = $1; }
    $Ivyobj->bindRegexp($regexp, [ "unused", \&callback] );
}


$Ivyobj->start;

no strict 'subs';
my $IN = $term->IN;
use strict 'subs';



sub cb {
    my $line = $term->readline("> ");
    $term->addhistory($line);
    chomp $line;
    exit if (&interpret_line ($line));
}

Ivy->fileEvent($IN, \&cb);
Ivy->mainLoop;
#my $mw = MainWindow->new();
#$mw->fileevent($IN, 'readable' => \&cb);
#MainLoop;



# this function has 3 additionnal parameters till Ivy Version 4.6
# and now getting the new/dying applications is straightforward.
# The first 3 parameters are kept only for upward compatibility! 
sub statusFunc {
    my ($ref_ready, $ref_nonReady, $ref_hashReady, $appname, $status, $host_or_regexp) = @_;

    if ($status eq "new") {
	print $OUT "$appname connected from $host_or_regexp\n";
	$where_applications{"$appname:$host_or_regexp"}++;
    }
    elsif ($status eq "died") {
	print $OUT "$appname disconnected from $host_or_regexp\n";
	$where_applications{"$appname:$host_or_regexp"}--;
    }
    elsif ($status eq 'subscribing') {
	print $OUT "$appname subscribed to '$host_or_regexp'\n";
    }
    elsif ($status eq 'unsubscribing') {
	print $OUT "$appname unsubscribed to '$host_or_regexp'\n";
    }
    else {
	print $OUT "Bug: unkown status; $status in &statusFunc\n";
    }
    
    %connected_applications = %$ref_hashReady;
}



# return 1 if exit!
sub interpret_line {
    my ($str) = @_;
    if ($str eq "") { return 0; } print "$str\n";
    if ($str =~ /^([^\.])/) {
	my $count=$Ivyobj->sendMsgs($str);
	print $OUT "-> Sent to $count peer";
	if ($count > 1) { print $OUT "s" }
	print $OUT "\n";
	return 0;
    }
    if ($str =~ /^\.q(uit)?\s*$/) {
	return 1;
    }
    if ($str =~ /^\.h(elp)?\s*$/) {
	&line_command_usage;
	return 0;
    }

    if ($str =~ /^\.die\s+(\S*)/) {
	$Ivyobj->sendDieTo($1);
	return 0;
    }

    if ($str =~ /^.b(ind)?\s+(.*)$/) {
	my $regexp = $2;
	if ($regexp =~ /'(.*)'/) { $regexp = $1; }
	print $OUT "binding $regexp\n";
	$Ivyobj->bindRegexp($regexp, [ "unused", \&callback] );
	return 0;
    }

    if ($str =~ /^.u(nbind)?\s+(.*)$/) {
	my $regexp = $2;
	if ($regexp =~ /'(.*)'/) { $regexp = $1; }
	print $OUT "unbinding $regexp\n";
	$Ivyobj->bindRegexp($regexp);
	return 0;
    }

    if ($str =~ /^.db(ind)?\s+(.*)$/) {
	my $id = $2;
	print $OUT "direct binding id $id\n";
	$Ivyobj->bindDirect($id, [\&directCallback] );
	return 0;
    }

    if ($str =~ /^.d(irect)?\s+(\S+)\s+(\S+)\s+(.*)$/) {
	my $appname = $2;
	my $id = $3;
	my $data = $4;
	print $OUT "send direct to $appname id=$id $data\n";
	$Ivyobj->sendDirectMsgs($appname, $id, $data);
	return 0;
    }

    if ($str =~ /^.p(ing)?\s+(\S+)\s+(\d+)\s*$/) {
	my $appname = $2;
	my $timeout = $3;
	print $OUT "ping $appname timeout=$timeout\n";
	my $res = $Ivyobj->ping($appname, $timeout);
	print $OUT "$res\n";
	return 0;
    }

    if ($str =~ /^.who\s*$/) {
	print $OUT "Apps:";
	foreach my $app (sort keys %connected_applications) {
	    for (my $i=0; $i<$connected_applications{$app} ; $i++) {
		print $OUT " $app";
	    }
	}
	print $OUT "\n";
	return 0;
    }

    if ($str =~ /^.where\s+(\S+)$/) {
	my $appli = $1;
	my $found = 0;
	foreach my $app_host (keys %where_applications) {
	    my ($app,$host) = $app_host =~ /(.+):(.*)/ ;
	    if ($app eq $appli) {
		for (my $i=0; $i<$where_applications{$app_host}; $i++) {
		    print $OUT "Application $app on $host\n";
		    $found = 1;
		}
	    }
	}
	print $OUT "No Application $appli\n" unless ($found);
	return 0;
    }

    print $OUT "bad command. Type '.help' for a list of commands\n";
    return 0;
    
}

sub callback {
    my ($unused, $appname, @param) = @_;

    my $paramString = "";
    if (scalar @param) { $paramString = join ("' '", @param); }
    print $OUT "$appname sent '", $paramString, "'\n";
}

sub directCallback {
    my (@param) = @_;

    my $paramString = "";
    if (scalar @param) { $paramString = join ("|", @param); }
    print $OUT "directMessage received '", $paramString, "'\n";
}


sub check_options {
    # on traite la ligne de commande
    my ($opt_help, $opt_gf);
    GetOptions("help" => \$opt_help,
	       "b:s"    => \$bus,
	       );

    &usage if ($opt_help && $opt_help);
}


sub usage {
    print $OUT "ivyprobe.pl [-h] [ -b <network>:<port> ]  ['regexp']*\n";
    print $OUT " ivyprobe.pl is a simple test application for the ivy-perl library\n";
    print $OUT " Its is based on a similar appplication available with ivy-c\n";
    print $OUT " It waits for messages on the bus, messages writtten on the command line\n";
    print $OUT " or commands issued on the comnand line\n";
    print $OUT " Help for the command line is available through the command\n";
    print $OUT " .help or .h\n";
    print $OUT "   -h   print this help\n";
    print $OUT "   -b   <network>:<port>\n";
    print $OUT "        to defined the network adress and the port number\n";
    print $OUT "        defaulted to 127:2010\n";
    exit;
}


sub line_command_usage { print "tutu\n";
    print $OUT "Commands list:\n";
    print $OUT "	.h[elp]				- this help\n";
    print $OUT "	.q[uit]				- terminate this application\n";
    print $OUT "	.b[ind] regexp			- add a msg to receive\n";
    print $OUT "	.u[nbind] regexp		- remove a msg to receive\n";
    print $OUT "	.die appname			- send die msg to appname\n";
    print $OUT "	.db[ind] id			- add a direct msg to receive\n";
    print $OUT "	.d[irect] appname id args	- send direct msg to appname\n";
    print $OUT "	.p[ing] appname timeout		- ping appname with a delay of timeout ms NYI\n";
    print $OUT "	.where appname			- on which host is/are appname\n";
    print $OUT "	.who				- who is on the bus\n";
}


__END__


=head1 NAME

ivyprobe.pl - simple application to test ivy, to test other ivy-application or the perl ivy implementation.

=head1 SYNOPSIS

B<ivyprobe.pl> [-h] [-b <network>:<port> ]  ['regexp']*

=head1 DESCRIPTION

B<ivyprobe.pl> connects to the bus and offers a simple text interface to receive and send messages, and to subscribe to messages. It is very similar to the C version named ivyprobe.

If regexps are given as parameters it subscribes to theses regexp.

To send a message, just type this message on the command line. It will be send to all applications who subscribe to this message. The number of application to which the message is sent is displayed.

The user can input the following commands:

=over

=item B<.h[elp]>

to get the list of available commands and short explanations

=item B<.q[uit]>

to terminate the application.

=item B<.b[ind] regexp>

to add a subscription to messages matching the regexp.

=item B<.die appname>

to send a die msg to appname. This application will stop.

=item B<.db[ind] id>

to add a direct msg of type id to receive

=item B<.d[irect] appname id string>

to send a direct msg to appname. The message type is indicated by id

=item B<.u[nbind] regexp>

To unsubscribe to messages matching the regexp

=item B<.where appname>

To get the host on which appname is/are running

=item B<.who>

to get the list of all connected applications

=back

=head1 BUGS

It is currently not possible to send a message which begin with a dot. It will be interpreted as a command (usually unknown!)

It sould be possible to use line editing capabilities, but does not work currently.

No other know bugs at this time. Report them to author.


=head1 SEE ALSO

ivy-perl(1), perl(1)

=head1 AUTHORS

Christophe Mertz <mertz@cena.fr>

=head1 COPYRIGHT

CENA (C) 2000-2002

=cut
